 
public class Aplicacao
{
    public static void main(String args[]) {
    	// Cria GUI para Josephus (qtdeSoldados, intervalo, tempoEspera)
        JosephusGuiTeste jsfg = new JosephusGuiTeste(50, 2, 300); 
        
        // mostra GUI
        jsfg.mostrarGui(); 
    }
}
 