 

/**
 * Contem assinaturas do metodos da TAD Lista Duplamente Ligada
 * 
 * @author Gabriel Ferreira Lima Silva - Douglas Cavalcanti Teles dos Santos - Raul Costa
 * @version 1.1 20190611
 */
public interface IListaDuplamenteLigadaCircular{
    public boolean estaVazia();
    
    public Object getInicio();
    
    public void inserirInicio(Object elem);

    public void inserirFim(Object elem);
    
    public boolean inserirApos(int chave, Object novo);

    public Object removerInicio();
    
    public Object removerFim();
    
    public Object removerPelaChave(int chave);
    
    public Object removerPelaChaveEndereço(Object chave);
    
    public boolean temUmElemento();
    
    public String toString();
    
    public String toStrinDoFim();
}
