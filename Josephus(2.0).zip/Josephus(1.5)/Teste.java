
/**
 * Escreva a descrição da classe Teste aqui.
 * 
 * @author Gabriel Ferreira Lima Silva - Douglas Cavalcanti Teles dos Santos - Raul Costa 
 * @version 1.1 20190611
 */
public class Teste
{
    public static void main(String args[]){
        int inter = 2;
        double tempo = 1000;
        int individuos = 10;
        //boolean verif = false;
        JosephusInterface jogo = new JosephusInterface(individuos, inter, tempo); 
        Josephus test = new Josephus(jogo.getIntervalo(), 0.0);
        jogo.mostrarGui();

        do{
            //jogo.setQtdIndividuos(individuos);
            //jogo.setVerif(verif);
            test.inserir(jogo.getQtdIndividuos());
            test.setIntervalo(jogo.getIntervalo());
            jogo.setPermut(test.eliminarSemEtapas());
        }while(!jogo.getVerif());
        //verif = jogo.getVerif();
        //test.inserir(10);
        //String s = test.exibirLista();
        //System.out.println(s);
        //test.eliminarSemEtapas();
    }
}
